﻿using herenciaypoli;


Console.WriteLine("=== AUTOS ===");

Vehiculo miCarrito = new Vehiculo(2010, "Azul", "Aston Martin");

Vehiculo elOtro = new Vehiculo(2009, "Rojo", "Ferrari");

carroelectrico miBYD = new carroelectrico(2026, "Amarillo", "BYD");


miBYD.InformacionVehiculo();
miBYD.cargarbateria();
miBYD.acelerar(20);
miBYD.Frenar();
Console.WriteLine("El nivel de bateria es: {0}", miBYD.nivelbateria());

Console.WriteLine("=== AUTO DE COMBUSTION===");
autodecombustion carrocom = new autodecombustion(2002, "Blanco", "freightliner",80,10.5);

carrocom.InformacionVehiculo();
carrocom.Encender();
carrocom.acelerar(20);
carrocom.Frenar();
Console.WriteLine("El nivel de Gasolina es: {0}", carrocom.Nivelgasolina());

Console.WriteLine("=== MOTOCICLETA ===");

Motocicleta moto = new Motocicleta(2020, "Roja", "Suzuki", 250, 0.5);
moto.InformacionVehiculo();
moto.Encender();
moto.acelerar(50);
moto.Frenar();
moto.CargarGasolina(30);
Console.WriteLine($"Nivel de Gasolina : {moto.Nivelcombustible()}");


Console.WriteLine("=== CAMION ===");

Camion miCamion = new Camion(2020, "Azul", "Volvo FH16", 10000, 1.5);

miCamion.InformacionVehiculo();
miCamion.Encender();
miCamion.CargarMercancia(5000);
miCamion.acelerar(60);
miCamion.Frenar();
Console.WriteLine($"Peso cargado: {miCamion.PesoCargado()}");
