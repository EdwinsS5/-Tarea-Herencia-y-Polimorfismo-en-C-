﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herenciaypoli
{
    internal class carroelectrico : Vehiculo
    {
        private int cargabateria;
        public carroelectrico(int anio, string elColor, string elModelo): base (anio, elColor, elModelo)
        {
            cargabateria = 50;
        }

        public override void acelerar(int cuanto)
        {
            base.acelerar(cuanto);
            cargabateria--;
        }

        public int nivelbateria() { return cargabateria; }
        public void cargarbateria()
        {
            cargabateria++;
        }
    }
}
