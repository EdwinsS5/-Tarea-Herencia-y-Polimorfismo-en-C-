﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herenciaypoli
{
    internal class Motocicleta : Vehiculo
    {
        private int cilindrada;
        private int nivelcombustible;
        private double consumocombustible;

        public Motocicleta(int anio, string elColor, string elModelo, int cilindrada, double consumocombustible) : base(anio, elColor, elModelo)
        {
            this.cilindrada = cilindrada;
            this.consumocombustible = consumocombustible;
            this.nivelcombustible = 100;
        }

        public override void acelerar(int cuanto)
        {
           if(nivelcombustible > 0)
            {
                base.acelerar(cuanto);
                double consumoajustado = consumocombustible * (cilindrada / 1000.0);
                nivelcombustible -= (int)(consumocombustible * cuanto);
                if (nivelcombustible < 0) nivelcombustible = 0;
                Console.WriteLine("Gasolina Restante: {0}", nivelcombustible);
            }
            else
            {
                Console.WriteLine("No hay suficiente gasolina echale unos 10 pesos");
            }
        }

        public override void Frenar()
        {
            Console.WriteLine("Frenando la motocicleta...");
            nivelcombustible -= (int)(consumocombustible * 0.1);
            if (nivelcombustible < 0) nivelcombustible = 0;
            Console.WriteLine($"Gasolina restante: {nivelcombustible}");
        }

        public void CargarGasolina(int cantidad)
        {
            if(nivelcombustible + cantidad <= 100)
            {
                nivelcombustible += cantidad;
                Console.WriteLine($"Gasolina cargada. Nivel actual: {nivelcombustible}");
            }
            else
            {
                Console.WriteLine("El tanque esta lleno");
            }
        }

        public override void Encender()
        {
            if(nivelcombustible > 0)
            {
                base.Encender();
                Console.WriteLine($"Motocicleta encendida: { cilindrada} cc");
            }
            else
            {
                Console.WriteLine("No hay suficiente gasolina echale unos 10 pesos");
            }
        }

        public int Nivelcombustible()
        {
            return nivelcombustible;
        }
    }
}
