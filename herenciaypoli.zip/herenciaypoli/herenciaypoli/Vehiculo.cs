﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herenciaypoli
{
    internal class Vehiculo
    {
        public string Color { get; set; }
        public string Modelo { get; set; }
        public int Year { get; set;}

        private int velocidad = 0;

        public Vehiculo(int anio, string elColor, string elModelo)
        {
            this.Color = elColor;
            this.Modelo = elModelo;
            this.Year = anio;

        }

        public void InformacionVehiculo()
        {
            Console.WriteLine("Color: {0}", this.Color);
            Console.WriteLine("Modelo: {0}:", this.Modelo);
            Console.WriteLine("Año: {0}", this.Year);
        }

        public virtual void acelerar(int cuanto)
        {
            velocidad += cuanto;
            Console.WriteLine("Vas a {0} KMS / Hora", velocidad);
        }

        public virtual void Frenar()
        {
            Console.WriteLine("Frenando el Vehiculo...");
            velocidad -= 10;

        }
        public virtual void Encender()
        {
            Console.WriteLine("Encendiendo el vehiculo...");
        }

        public virtual void Apagar()
        {
            Console.WriteLine("Apagando el vehiculo...");
        }
    }
}
