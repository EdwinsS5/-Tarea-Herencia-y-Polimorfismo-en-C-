﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herenciaypoli
{
    internal class autodecombustion : Vehiculo
    {
        private int capacidadtanque;
        private int nivelgasolina;
        private double consumogasolina;

        

        public autodecombustion(int anio, string elColor, string elModelo, int capacidadtanque, double consumogasolina): base (anio, elColor, elModelo)
        {
            this.capacidadtanque = capacidadtanque;
            this.consumogasolina = consumogasolina;
            this.nivelgasolina = 100;
        }

        public override void acelerar(int cuanto)
        {
            base.acelerar(cuanto);
            nivelgasolina -= 5;
            Console.WriteLine("Gasolina restante: {0}%", nivelgasolina);
        }

        public override void Frenar()
        {
            Console.WriteLine("Frenando el auto de combustion.");
            nivelgasolina -= (int)(consumogasolina * 0.1);
            Console.WriteLine($"Gasolina Restante: {nivelgasolina}");
        }
        
        public void cargargasolina(int cantidad)
        {
            if (nivelgasolina + cantidad <= capacidadtanque)
            {
                nivelgasolina += cantidad;
                Console.WriteLine($"Combustible cargado. Nivel actual: {nivelgasolina}");
            }
            else
            {
                Console.WriteLine("El tanque esta lleno");
            }
        }

        public override void Encender()
        {
            base.Encender();
        }
        public int Nivelgasolina()
        {
            return nivelgasolina;
        }
    }
}
