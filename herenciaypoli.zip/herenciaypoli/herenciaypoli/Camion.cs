﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace herenciaypoli
{
    internal class Camion: Vehiculo
    {
        private int capacidadcarga;
        private int pesocargado;
        private double consumodiesel;

        public Camion(int anio, string elColor, string elModelo, int capacidadcarga, double consumodiesel) : base(anio, elColor, elModelo)
        {
            this.capacidadcarga = capacidadcarga;
            this.consumodiesel = consumodiesel;
            this.pesocargado = 0;
        }

        public override void acelerar(int cuanto)
        {
            if(pesocargado <= capacidadcarga)
            {
                base.acelerar(cuanto);
                consumodiesel += 0.1 * (pesocargado / 1000);
                Console.WriteLine($"Consumo Diesel: {consumodiesel}");
            }
            else
            {
                Console.WriteLine("El camion esta sobrecargado");
            }
        }

        public override void Frenar()
        {
            base.Frenar();
            consumodiesel -= 0.05;
            if (consumodiesel < 0.5) consumodiesel = 0.5;
            Console.WriteLine($"Consumo de Diesel: {consumodiesel}");
        }

        public void CargarMercancia(int peso)
        {
            if(pesocargado + peso <= capacidadcarga)
            {
                pesocargado += peso;
                Console.WriteLine($"Mercancia cargada. Peso actual : {pesocargado}");
            }
            else
            {
                Console.WriteLine("No se puede cargar mas");
            }
        }

        public override void Encender()
        {
            if(pesocargado <= capacidadcarga)
            {
                base.Encender();
                Console.WriteLine("Camion Encendido.");
            }
            else
            {
                Console.WriteLine("El camion esta sobrecardado");   
            }
            
        }

        public int PesoCargado()
        {
            return pesocargado;
        }
    }
}
